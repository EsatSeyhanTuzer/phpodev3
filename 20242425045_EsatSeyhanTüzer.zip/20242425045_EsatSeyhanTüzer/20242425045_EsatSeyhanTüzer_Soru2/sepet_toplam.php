<?php
function temizle($veri) {
    $veri = trim($veri);
    $veri = stripslashes($veri);
    return htmlspecialchars($veri, ENT_QUOTES, 'UTF-8');
}

function paraYaz($deger) {
    return number_format($deger, 2, ',', '.');
}

$hata = '';
$urunAdi = '';
$fiyat = 0.0;
$adet = 0;
$kdv = 0.0;
$indirimKodu = '';
$indirimOrani = 0;
$araToplam = 0.0;
$kdvTutari = 0.0;
$indirimTutari = 0.0;
$genelToplam = 0.0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $urunAdi = isset($_POST['urun_adi']) ? temizle($_POST['urun_adi']) : '';
    $fiyatGirdi = isset($_POST['urun_fiyati']) ? $_POST['urun_fiyati'] : '';
    $adetGirdi = isset($_POST['adet']) ? $_POST['adet'] : '';
    $kdvGirdi = isset($_POST['kdv']) ? $_POST['kdv'] : '';
    $indirimKodu = isset($_POST['indirim_kodu']) ? strtoupper(temizle($_POST['indirim_kodu'])) : '';

    if ($urunAdi === '' || $fiyatGirdi === '' || $adetGirdi === '' || $kdvGirdi === '') {
        $hata = 'Lütfen zorunlu tüm alanları doldurun.';
    } else {
        $fiyat = (float)$fiyatGirdi;
        $adet = (int)$adetGirdi;
        $kdv = (float)$kdvGirdi;

        if ($fiyat < 0 || $adet < 1 || $kdv < 20) {
            $hata = 'Fiyat negatif olamaz, adet en az 1 olmalı ve KDV en az %20 olmalıdır.';
        } else {
            if ($indirimKodu === 'IND20') {
                $indirimOrani = 20;
            } elseif ($indirimKodu === 'IND50') {
                $indirimOrani = 50;
            } else {
                $indirimOrani = 0;
            }

            $araToplam = $fiyat * $adet;
            $kdvTutari = $araToplam * ($kdv / 100);
            $indirimTutari = $araToplam * ($indirimOrani / 100);
            $genelToplam = $araToplam + $kdvTutari - $indirimTutari;
        }
    }
} else {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sepet Toplamı Sonucu</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Sepet Sonucu</h1>

        <?php if ($hata !== ''): ?>
            <p class="message error"><?php echo $hata; ?></p>
        <?php else: ?>
            <div class="result-box">
                <p><strong><?php echo $urunAdi; ?></strong> için toplam tutar: <strong><?php echo paraYaz($genelToplam); ?> TL</strong></p>
                <p><strong>Birim Fiyat:</strong> <?php echo paraYaz($fiyat); ?> TL</p>
                <p><strong>Adet:</strong> <?php echo $adet; ?></p>
                <p><strong>Ara Toplam:</strong> <?php echo paraYaz($araToplam); ?> TL</p>
                <p><strong>KDV Tutarı:</strong> <?php echo paraYaz($kdvTutari); ?> TL</p>

                <?php if ($indirimOrani > 0): ?>
                    <p><strong>"<?php echo $indirimKodu; ?>"</strong> indirim kodu uygulanmıştır ve <strong>İndirim Tutarı:</strong> <?php echo paraYaz($indirimTutari); ?> TL</p>
                <?php else: ?>
                    <p><strong>İndirim:</strong> Uygulanmadı</p>
                <?php endif; ?>

                <p class="total"><strong>Genel Toplam:</strong> <?php echo paraYaz($genelToplam); ?> TL</p>
            </div>
        <?php endif; ?>

        <a class="back-link" href="index.php">Geri Dön</a>
    </div>
</body>
</html>
