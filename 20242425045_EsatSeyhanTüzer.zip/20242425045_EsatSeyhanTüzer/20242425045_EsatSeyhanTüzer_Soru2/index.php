<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soru 2 - Alışveriş Sepeti</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Alışveriş Sepeti Toplamı</h1>
        <form action="sepet_toplam.php" method="POST" autocomplete="off">
            <label for="urun_adi">Ürün Adı</label>
            <input type="text" id="urun_adi" name="urun_adi" required>

            <label for="urun_fiyati">Ürün Fiyatı</label>
            <input type="number" id="urun_fiyati" name="urun_fiyati" step="0.01" min="0" required>

            <label for="adet">Ürün Adedi</label>
            <input type="number" id="adet" name="adet" min="1" required>

            <label for="kdv">KDV Oranı (%)</label>
            <input type="number" id="kdv" name="kdv" min="20" required>

            <label for="indirim_kodu">İndirim Kodu</label>
            <input type="text" id="indirim_kodu" name="indirim_kodu" placeholder="IND20 veya IND50">

            <button type="submit">Hesapla</button>
        </form>
    </div>
</body>
</html>
