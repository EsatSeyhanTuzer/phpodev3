<?php
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soru 1 - Kullanıcı Giriş Sistemi</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Kullanıcı Giriş Sistemi</h1>
        <form action="kullanici_kontrol.php" method="POST" autocomplete="off">
            <label for="kullanici_adi">Kullanıcı Adı</label>
            <input type="text" id="kullanici_adi" name="kullanici_adi" required>

            <label for="sifre">Şifre</label>
            <input type="password" id="sifre" name="sifre" required>

            <button type="submit">Giriş Yap</button>
        </form>
    </div>
</body>
</html>
