<?php
function temizle($veri) {
    $veri = trim($veri);
    $veri = stripslashes($veri);
    return htmlspecialchars($veri, ENT_QUOTES, 'UTF-8');
}

$mesaj = "";
$sinif = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kullaniciAdi = isset($_POST['kullanici_adi']) ? temizle($_POST['kullanici_adi']) : '';
    $sifre = isset($_POST['sifre']) ? temizle($_POST['sifre']) : '';

    if ($kullaniciAdi === '' || $sifre === '') {
        $mesaj = 'Lütfen tüm alanları doldurun';
        $sinif = 'error';
    } else if ($kullaniciAdi === 'admin' && $sifre === '1234') {
        $mesaj = 'Giriş başarılı, hoş geldiniz admin';
        $sinif = 'success';
    } else {
        $mesaj = 'Kullanıcı adı veya şifre hatalı';
        $sinif = 'error';
    }
} else {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Sonucu</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Giriş Sonucu</h1>
        <p class="message <?php echo $sinif; ?>"><?php echo $mesaj; ?></p>
        <a class="back-link" href="index.php">Geri Dön</a>
    </div>
</body>
</html>
